This is application v2

here micro services are dsicovered by using discovery server 
