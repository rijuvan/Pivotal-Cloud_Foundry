package com.soft.infg.weatherapp;

import javax.inject.Inject;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class WeatherService {
	
	@Inject
private RestTemplate restTemplate ;
	
	
	

	

	//@HystrixCommand(fallbackMethod="unknown")
	public String getWeather()
	{
		System.err.println("ITS IS CALLED *********************************");
		System.err.println("ITS IS CALLED *********************************");
		System.err.println("ITS IS CALLED *********************************");
		System.out.println("ITS IS CALLED *********************************");
		System.out.println("ITS IS CALLED *********************************");
		System.out.println("ITS IS CALLED *********************************");
		
		
	return restTemplate.getForEntity("http://weather-service/weather", String.class).getBody();
	}
	
	public String unknown()
	{
		return "Unknown----not working!!";
	}

}

@Configuration
class AppConfiguration {

    @LoadBalanced
    @Bean
    RestTemplate restTemplate() {
        return new RestTemplate();
    }
}

